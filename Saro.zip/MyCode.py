from pyspark.sql import SparkSession
from pyspark.sql.functions import col, dense_rank, lag, max, initcap
from pyspark.sql.window import Window

spark = SparkSession.builder().appName().getOrCreate()

#Enabling AQE for dynamic optimization

spark.config.set("spark.sql.adaptive.enabled", true)

df1 = spark.read.format("csv").options("header", "true").load("/661774b492e8371c6b888561/Project-Default/Coding Challenge/onlinefoods.csv")


#standardizing column values 
df1 = df1.withColumn("Educational Qualifications", initcap(col("Educational Qualifications")))

windowSpec  = Window.partitionBy("Occupation").orderBy("Monthly Income")

# assigning Rank based on occupation and income

Rank_df = df1.withColumn("Rank", dense_rank().over(windowSpec))

# getting the diff between salaries 
windowSpec_Diff  = Window.orderBy("Rank")

Diff_df = Rank_df.withColumn("Diff_Sal",lag("salary",2).over(windowSpec_Diff)) \
      .show()
      
      
#Max salary of each occupation based on feedback

Max_salary = Diff_df.GroupBy(col("Occupation")).agg(max(col("Monthly Income")))

Max_salary.display()

Final_df = Max_salary.filter(col("Feedback") == "Positive")

# using broadcast join for optimization

spark.config.set("spark.sql.broadcast.enabled", true)


Male_df = Final_df.filter(col("Gender") == "Male")
Female_df = Final_df.filter(col("Gender") == "Female")

Join_df = Male_df.join(Female_df, on = 'id', 'broadcast')

